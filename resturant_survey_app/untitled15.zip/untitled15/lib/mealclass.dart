class Meal {
  final String name;
  final String image;
  Meal({required this.name, required this.image});
}
