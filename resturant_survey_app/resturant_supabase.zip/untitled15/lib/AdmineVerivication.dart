import 'package:flutter/material.dart';
import 'admine_page.dart'; //

class AdmineVerivicationPage extends StatelessWidget {
  AdmineVerivicationPage({super.key});

  final TextEditingController _verificationCodeController =
      TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFFFB300),
        foregroundColor: Colors.white,
        title: Text(
          'Manager Verification',
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ), //  العنوان
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            TextField(
              controller: _verificationCodeController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                hintText: 'password',
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                int? verificationCode = int.tryParse(
                  _verificationCodeController.text,
                );
                if (verificationCode != null &&
                    verificationCode >= 1 &&
                    verificationCode <= 10) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AdminPage()),
                  );
                } else {
                  showDialog(
                    context: context,
                    builder:
                        (context) => AlertDialog(
                          title: Text('error'),
                          content: Text("password isn't correct"),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context),
                              child: Text('nice'),
                            ),
                          ],
                        ),
                  );
                }
              },
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text(
                  'Go to Dashboard',
                  style: TextStyle(fontSize: 20),
                ), //  نص الزر
              ),
            ),
          ],
        ),
      ),
    );
  }
}
