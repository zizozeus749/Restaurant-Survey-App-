import 'package:flutter/material.dart';
import 'menu_page.dart';
import 'AdmineVerivication.dart'; //
import 'menu_page.dart';

class HomePage extends StatelessWidget {
  HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFFFB300),
        foregroundColor: Colors.white,
        title: Text(
          'Restaurant Survey',
          style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
        ),
      ),
      body: Center(
        // توسيط الأزرار
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center, // توسيط عمودي
          children: <Widget>[
            // تم تغيير [] إلى <Widget>[]
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => AdmineVerivicationPage(),
                  ), // توجيه إلى صفحة التحقق
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text('Manager', style: TextStyle(fontSize: 20)),
              ),
            ),
            SizedBox(height: 20), // مسافة بين الأزرار
            ElevatedButton(
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => MenuPage()),
                );
              },
              child: Padding(
                padding: const EdgeInsets.all(12.0),
                child: Text('Customer', style: TextStyle(fontSize: 20)),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
