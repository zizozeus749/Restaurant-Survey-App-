import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_rating_bar/flutter_rating_bar.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'menucontroller.dart';
import 'mealclass.dart';
import 'model.dart';
import 'main.dart';

class SelectedMealsPage extends StatefulWidget {
  const SelectedMealsPage({super.key});

  @override
  State<SelectedMealsPage> createState() => _SelectedMealsPageState();
}

class _SelectedMealsPageState extends State<SelectedMealsPage> {
  final CustomMenuController controller = Get.find();
  Map<String, TextEditingController> commentControllers = {};
  Map<String, double> ratings = {};
  final SupabaseClient supabase = Supabase.instance.client;

  @override
  void initState() {
    super.initState();
    for (int i = 0; i < controller.meals.length; i++) {
      if (controller.selectedItems[i]) {
        String mealName = controller.meals[i].name;
        commentControllers[mealName] = TextEditingController();
        ratings[mealName] = 0;
      }
    }
  }

  Future<void> saveFeedback() async {
    List<dynamic> storedFeedback = [];

    for (var meal in controller.meals) {
      if (controller.selectedItems[controller.meals.indexOf(meal)]) {
        final name = meal.name;
        final comment = commentControllers[name]?.text ?? '';
        final ratingDouble = ratings[name] ?? 0;
        final rating = ratingDouble.round(); // ✅ تحويل double إلى int

        if (rating > 0 || comment.isNotEmpty) {
          final model = Model(
            mealName: name,
            rating: rating,
            feedback: comment,
            customerName: 'Manar',
            customerNumber: '01061346948',
          );

          try {
            final response = await supabase.from('Mero').insert(model.toJson());

            if (response == null) {
              print("الرد من Supabase فارغ");
            } else {
              print("تم الإدخال بنجاح: ${model.toJson()}");
            }

            storedFeedback.add(model.toJson());
          } catch (e) {
            print("خطأ أثناء الإدخال إلى Supabase: $e");
            Get.snackbar(
              "Error",
              "حدث خطأ أثناء حفظ التقييم",
              backgroundColor: Colors.red,
              colorText: Colors.white,
            );
          }
        }
      }
    }

    if (storedFeedback.isNotEmpty) {
      Get.snackbar(
        "Success",
        "Feedback saved to database",
        backgroundColor: Colors.green,
        colorText: Colors.white,
      );
    } else {
      Get.snackbar(
        "No Feedback",
        "لم يتم إدخال أي تقييم أو تعليق",
        backgroundColor: Colors.orange,
        colorText: Colors.white,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final selectedNames = Get.arguments as List<String>;

    return Scaffold(
      appBar: AppBar(
        title: const Text("Selected Meals"),
        backgroundColor: const Color(0xFFFFB300),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount: controller.meals.length,
                itemBuilder: (context, index) {
                  if (controller.selectedItems[index]) {
                    final meal = controller.meals[index];
                    return Card(
                      margin: const EdgeInsets.all(10),
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          children: [
                            Image.asset(
                              meal.image,
                              height: 200,
                              width: double.infinity,
                              fit: BoxFit.cover,
                            ),
                            const SizedBox(height: 10),
                            Text(
                              meal.name,
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                            const SizedBox(height: 10),
                            RatingBar.builder(
                              initialRating: ratings[meal.name] ?? 0,
                              minRating: 1,
                              allowHalfRating: true,
                              itemCount: 5,
                              itemSize: 30,
                              itemBuilder:
                                  (context, _) => const Icon(
                                    Icons.star,
                                    color: Colors.amber,
                                  ),
                              onRatingUpdate: (rating) {
                                setState(() {
                                  ratings[meal.name] = rating;
                                });
                              },
                            ),
                            const SizedBox(height: 10),
                            TextField(
                              controller: commentControllers[meal.name],
                              decoration: const InputDecoration(
                                hintText: "Add your feedback here...",
                                border: OutlineInputBorder(),
                              ),
                              maxLines: 3,
                            ),
                          ],
                        ),
                      ),
                    );
                  } else {
                    return Container();
                  }
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: saveFeedback,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFFFFB300),
                  padding: const EdgeInsets.symmetric(
                    vertical: 15,
                    horizontal: 50,
                  ),
                ),
                child: const Text(
                  'Send',
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
