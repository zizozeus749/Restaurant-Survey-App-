import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class MealRating {
  final String name;
  final double averageRating;
  final List<String> comments;

  MealRating({
    required this.name,
    required this.averageRating,
    required this.comments,
  });

  factory MealRating.fromJson(Map<String, dynamic> json) {
    return MealRating(
      name: json['meal_name'],
      averageRating: (json['rating'] as num?)?.toDouble() ?? 0.0,
      comments: (json['feedback'] != null) ? [json['feedback'] as String] : [],
    );
  }
}

class AdminPage extends StatefulWidget {
  const AdminPage({super.key});

  @override
  State<AdminPage> createState() => _AdminPageState();
}

class _AdminPageState extends State<AdminPage> {
  final SupabaseClient supabase = Supabase.instance.client;
  List<MealRating> allMeals = [];
  List<MealRating> filteredMeals = [];
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    try {
      final List<dynamic> response =
          await supabase.from('Mero').select() as List<dynamic>;

      if (response.isEmpty) {
        print('No data returned');
        setState(() {
          _isLoading = false;
        });
        return;
      }

      Map<String, Map<String, dynamic>> mealData = {};
      for (var row in response) {
        final name = row['meal_name'] as String;
        final rating = row['rating'] as num?;
        final comment = row['feedback'] as String?;

        if (!mealData.containsKey(name)) {
          mealData[name] = {
            'sum': rating ?? 0,
            'count': 1,
            'comments': comment != null ? [comment] : [],
          };
        } else {
          mealData[name]!['sum'] =
              (mealData[name]!['sum'] as num) + (rating ?? 0);
          mealData[name]!['count'] = (mealData[name]!['count'] as int) + 1;
          if (comment != null) {
            (mealData[name]!['comments'] as List).add(comment);
          }
        }
      }

      List<MealRating> meals =
          mealData.entries.map((e) {
            final avg = (e.value['sum'] as num) / (e.value['count'] as int);
            final comms = List<String>.from(e.value['comments'] as List);
            return MealRating(
              name: e.key,
              averageRating: avg.toDouble(),
              comments: comms,
            );
          }).toList();

      setState(() {
        allMeals = meals;
        filteredMeals = meals;
        _isLoading = false;
      });
    } catch (e) {
      print('Error: $e');
      setState(() {
        _isLoading = false;
      });
    }
  }

  void filterMeals(String filterType) {
    List<MealRating> filteredList;
    if (filterType == 'Best') {
      filteredList = allMeals.where((meal) => meal.averageRating >= 4).toList();
    } else if (filterType == 'Worst') {
      filteredList = allMeals.where((meal) => meal.averageRating < 2).toList();
    } else {
      filteredList =
          allMeals
              .where((meal) => meal.averageRating > 2 && meal.averageRating < 4)
              .toList();
    }

    setState(() {
      filteredMeals = filteredList;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Admin Dashboard"),
        backgroundColor: const Color(0xFFFFB300),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child:
            _isLoading
                ? const Center(child: CircularProgressIndicator())
                : Column(
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        ElevatedButton(
                          onPressed: () => filterMeals('Best'),
                          child: const Text("أفضل الوجبات"),
                        ),
                        const SizedBox(width: 20),
                        ElevatedButton(
                          onPressed: () => filterMeals('Worst'),
                          child: const Text("أضعف الوجبات"),
                        ),
                        const SizedBox(width: 20),
                        ElevatedButton(
                          onPressed: () => filterMeals('Average'),
                          child: const Text("الوجبات المتوسطة"),
                        ),
                      ],
                    ),
                    Expanded(
                      child: ListView.builder(
                        itemCount: filteredMeals.length,
                        itemBuilder: (context, index) {
                          final meal = filteredMeals[index];
                          return Card(
                            margin: const EdgeInsets.all(10),
                            child: Padding(
                              padding: const EdgeInsets.all(16.0),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    meal.name,
                                    style: const TextStyle(
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    'Average Rating: ${meal.averageRating.toStringAsFixed(2)}',
                                    style: const TextStyle(fontSize: 16),
                                  ),
                                  const SizedBox(height: 10),
                                  Text(
                                    'Comments:',
                                    style: const TextStyle(
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                  const SizedBox(height: 10),
                                  for (var comment in meal.comments)
                                    Text('- $comment'),
                                ],
                              ),
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
      ),
    );
  }
}
