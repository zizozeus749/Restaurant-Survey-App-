import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'mealclass.dart';
import 'menucontroller.dart';
import 'selected_meals_page.dart';

class MenuPage extends StatelessWidget {
  const MenuPage({super.key});

  @override
  Widget build(BuildContext context) {
    final CustomMenuController controller = Get.put(CustomMenuController());

    return Scaffold(
      appBar: AppBar(
        title: const Text("choice your meals please"),
        backgroundColor: Color(0xFFFFB300),
        foregroundColor: Colors.white,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // ListView.builder to display the meals
            Expanded(
              child: ListView.builder(
                itemCount: controller.meals.length,
                itemBuilder: (context, index) {
                  var meal = controller.meals[index]; // الوصول إلى meal
                  return Obx(
                    () => CheckboxListTile(
                      title: Row(
                        children: [
                          Image.asset(
                            meal.image,
                            width: 40,
                            height: 40,
                            errorBuilder: (context, error, stackTrace) {
                              return const Icon(Icons.error, color: Colors.red);
                            },
                          ),
                          const SizedBox(width: 10),
                          Text(meal.name),
                        ],
                      ),
                      value: controller.selectedItems[index],
                      onChanged: (bool? value) {
                        controller.updateSelection(index, value!);
                      },
                    ),
                  );
                },
              ),
            ),
            // Button after the ListView
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: ElevatedButton(
                onPressed: () {
                  final selectedNames =
                      controller.meals
                          .asMap()
                          .entries
                          .where((entry) => controller.selectedItems[entry.key])
                          .map((entry) => entry.value.name)
                          .toList();

                  Get.to(
                    () => const SelectedMealsPage(),
                    arguments: selectedNames,
                  );
                },

                style: ElevatedButton.styleFrom(
                  foregroundColor: Colors.white,
                  backgroundColor: Color(0xFFFFB300),
                ),
                child: const Text("Submit"),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
