package com.example.untitled15

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
